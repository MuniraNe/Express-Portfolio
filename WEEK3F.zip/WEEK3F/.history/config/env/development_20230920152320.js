module.exports = { 
	sessionSecret: 'developmentSessionSecret' 
};
